package com.example.nne2_javaexample1;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    int prev = 0;
    int _prev = 0;
    int _curt = 0;
    int eeg = 0;

    private static final int REQUEST_ENABLE_BT = 3;

    BluetoothAdapter mBluetoothAdapter = null;

    UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    BluetoothDevice btDevice;
    BluetoothSocket btSocket;

    private class BTFoundDevice {
        private String deviceName;
        private String deviceMac;

        public BTFoundDevice(String deviceMac, String deviceName) {
            this.deviceMac = deviceMac;
            this.deviceName = deviceName;
        }

        public String getDeviceName() {
            return deviceName;
        }

        public String getDeviceMac() {
            return deviceMac;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (mBluetoothAdapter == null) {
            //블루투스를 지원하지 않는 장치 입니다.
            Toast.makeText(this, "블루투스를 사용할 수 없습니다.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        connectDevice();
    }

    public void onStart() {
        super.onStart();

        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_ENABLE_BT:
                if (resultCode == MainActivity.RESULT_OK) {
                    Toast.makeText(this, "블루투스를 활성화 했습니다", Toast.LENGTH_LONG).show();
                    // 블루투스 adapter가 있으면, 블루투스 adater에서 페어링된 장치 목록을 불러올 수 있다.
                } else {
                    Toast.makeText(this, "블루투스를 활성화 하지 못했습니다", Toast.LENGTH_LONG).show();
                }
        }
    }

    public void connectDevice() {
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();

        if (pairedDevices.size() > 0) { // 하나 이상 검색될 경우

            for (BluetoothDevice device : pairedDevices) {
                BTFoundDevice deviceClass = new BTFoundDevice(device.getAddress(), device.getName());

                if (deviceClass.deviceName.equals("neuroNicle E2")) {
                    btDevice = mBluetoothAdapter.getRemoteDevice(deviceClass.deviceMac);
                    btSocket = null;
                    try {
                        btSocket = btDevice.createRfcommSocketToServiceRecord(MY_UUID);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    try {
                        btSocket.connect();
                    } catch (IOException connectException) {
                        connectException.printStackTrace();
                        try {
                            btSocket.close();
                        } catch (IOException closeException) {
                        }
                        return;
                    }

                    ConnectedThread connectedThread = new ConnectedThread(btSocket);
                    connectedThread.start();
                }
            }
        }
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;

        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;

            // BluetoothSocket의 inputstream 과 outputstream을 얻는다.
            try {
                tmpIn = socket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            mmInStream = tmpIn;
        }

        public void run() {
            String buf = "";
            String Data;
            StringBuffer packet = new StringBuffer();
            final TextView textView1 = (TextView) findViewById(R.id.textView) ;

            while (true) {
                try {
                    // InputStream으로부터 값을 받는 읽는 부분(값을 받는다)
                    Data = Integer.toHexString(mmInStream.read());

                    buf = Data;
                    if (buf.equals("ff")) {
                        Data = Integer.toHexString(mmInStream.read());
                        buf = Data;
                        if (buf.equals("fe")) {
                            final String str = packet.toString();
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    textView1.setText(str);
                                    String arr[] = str.split(" ");
                                    for(int i=0;i<arr.length;i++) {
                                        if( i == 7 || i == 8) {
                                            if(prev == 0) {
                                                prev = 1;
                                                _prev = Integer.parseInt(arr[i],16);
                                                _prev = _prev*256;
                                            }
                                            else if(prev == 1){
                                                prev = 0;
                                                _curt = Integer.parseInt(arr[i],16);
                                                eeg = _curt + _prev;
                                            }
                                        }
                                    }

                                }
                            });
//                                try{
//                                    Thread.sleep(100);
//                                }
//                                catch (InterruptedException e){
//
//                                }
                            packet.setLength(0);
                            packet.append("ff fe");
                        }
                        else {
                            packet.append(" ff");
                            packet.append(" "+buf);
                        }
                    }
                    else {
                        packet.append(" "+buf);
                    }
                } catch (IOException e) {
                    break;
                }
            }
        }
    }
    public void list(String data){

    }
}